'use client'

import { useState, useEffect, useCallback } from 'react'
import { Copy, Check, X, RefreshCw, QrCode, Clock, AlertCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { Order } from '@/lib/types'

interface PixModalProps {
  order: Order
  total: number
  pixKey: string
  storeName: string
  onClose: () => void
}

/* ── PIX EMV payload generator (BR BACEN spec) ── */
function tlv(id: string, value: string): string {
  return `${id}${String(value.length).padStart(2, '0')}${value}`
}

function crc16(str: string): number {
  let crc = 0xffff
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8
    for (let j = 0; j < 8; j++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff
    }
  }
  return crc
}

function buildPixPayload(pixKey: string, amount: number, name: string): string {
  const normalized = name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Za-z0-9 ]/g, '')
    .substring(0, 25)
    .trim() || 'CREMOSO BURGUER'

  const merchantAccount = tlv('26', tlv('00', 'br.gov.bcb.pix') + tlv('01', pixKey))
  const additionalData = tlv('62', tlv('05', '***'))

  const base =
    '000201' +
    '010212' +
    merchantAccount +
    tlv('52', '0000') +
    tlv('53', '986') +
    tlv('54', amount.toFixed(2)) +
    tlv('58', 'BR') +
    tlv('59', normalized) +
    tlv('60', 'BRASIL') +
    additionalData +
    '6304'

  return base + crc16(base).toString(16).toUpperCase().padStart(4, '0')
}

const TIMER_SECONDS = 5 * 60

const fmt = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

export function PixModal({ order, total, pixKey, storeName, onClose }: PixModalProps) {
  const [timeLeft, setTimeLeft] = useState(TIMER_SECONDS)
  const [expired, setExpired] = useState(false)
  const [copied, setCopied] = useState(false)
  const [generation, setGeneration] = useState(0)

  const pixPayload = buildPixPayload(pixKey, total, storeName || 'CREMOSO BURGUER')
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=12&data=${encodeURIComponent(pixPayload)}`

  const reset = useCallback(() => {
    setTimeLeft(TIMER_SECONDS)
    setExpired(false)
    setGeneration(g => g + 1)
  }, [])

  useEffect(() => {
    if (expired) return
    const id = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) { clearInterval(id); setExpired(true); return 0 }
        return t - 1
      })
    }, 1000)
    return () => clearInterval(id)
  }, [expired, generation])

  const minutes = Math.floor(timeLeft / 60)
  const seconds = timeLeft % 60
  const timerStr = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
  const urgency = timeLeft <= 60

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(pixPayload)
      setCopied(true)
      setTimeout(() => setCopied(false), 3000)
    } catch {
      /* fallback for older browsers */
      const el = document.createElement('textarea')
      el.value = pixPayload
      document.body.appendChild(el)
      el.select()
      document.execCommand('copy')
      document.body.removeChild(el)
      setCopied(true)
      setTimeout(() => setCopied(false), 3000)
    }
  }

  return (
    <div className="fixed inset-0 bg-background z-[60] overflow-y-auto">
      <div className="min-h-screen flex flex-col">

        {/* Header */}
        <div className="sticky top-0 bg-background border-b border-border p-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <QrCode className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-bold text-foreground">PAGAMENTO VIA PIX</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 p-4 max-w-md mx-auto w-full pb-10 space-y-5">

          {/* Order info */}
          <div className="bg-muted/50 rounded-xl p-4 flex justify-between items-center border border-border">
            <div>
              <p className="text-xs text-muted-foreground">Pedido</p>
              <p className="font-bold text-foreground">#{String(order.number).padStart(3, '0')}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Total a pagar</p>
              <p className="text-2xl font-bold text-primary">{fmt(total)}</p>
            </div>
          </div>

          {expired ? (
            /* Expired state */
            <div className="bg-destructive/10 border border-destructive/30 rounded-xl p-6 text-center space-y-4">
              <AlertCircle className="w-12 h-12 text-destructive mx-auto" />
              <div>
                <p className="font-bold text-foreground text-lg">Pagamento expirado</p>
                <p className="text-sm text-muted-foreground mt-1">
                  O tempo para pagamento expirou. Gere um novo código PIX.
                </p>
              </div>
              <Button
                onClick={reset}
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold w-full"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Gerar novo PIX
              </Button>
            </div>
          ) : (
            <>
              {/* Timer */}
              <div className={`rounded-xl border p-3 flex items-center justify-between transition-colors ${
                urgency
                  ? 'bg-destructive/10 border-destructive/40'
                  : 'bg-muted/50 border-border'
              }`}>
                <div className="flex items-center gap-2">
                  <Clock className={`w-4 h-4 ${urgency ? 'text-destructive' : 'text-muted-foreground'}`} />
                  <span className={`text-sm ${urgency ? 'text-destructive' : 'text-muted-foreground'}`}>
                    {urgency ? 'Expira em breve' : 'Válido por'}
                  </span>
                </div>
                <span className={`font-mono font-bold text-xl tabular-nums ${
                  urgency ? 'text-destructive' : 'text-foreground'
                }`}>
                  {timerStr}
                </span>
              </div>

              {/* QR Code */}
              <div className="bg-white rounded-2xl p-4 flex items-center justify-center shadow-sm">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  key={generation}
                  src={qrUrl}
                  alt="QR Code PIX"
                  width={220}
                  height={220}
                  className="rounded-lg"
                />
              </div>

              {/* Instructions */}
              <div className="space-y-1.5 text-sm text-muted-foreground">
                <p className="font-semibold text-foreground text-xs uppercase tracking-wide">Como pagar:</p>
                <p>1. Abra o app do seu banco</p>
                <p>2. Escaneie o QR Code acima <span className="text-foreground font-medium">ou</span> use o código abaixo</p>
                <p>3. Confirme o pagamento de <span className="text-primary font-bold">{fmt(total)}</span></p>
              </div>

              {/* PIX key display */}
              <div className="space-y-1.5">
                <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold">Chave PIX (Copia e Cola)</p>
                <div className="bg-muted rounded-xl border border-border p-3 flex items-start gap-3">
                  <p className="text-xs text-foreground font-mono break-all flex-1 leading-relaxed">
                    {pixPayload}
                  </p>
                  <button
                    onClick={handleCopy}
                    className={`shrink-0 p-2 rounded-lg transition-all ${
                      copied
                        ? 'bg-green-500/20 text-green-400'
                        : 'bg-primary/10 hover:bg-primary/20 text-primary'
                    }`}
                  >
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                {copied && (
                  <p className="text-xs text-green-400 flex items-center gap-1">
                    <Check className="w-3 h-3" /> Código copiado com sucesso!
                  </p>
                )}
              </div>

              {/* PIX key info */}
              <div className="bg-muted/30 rounded-xl border border-border p-4 space-y-2">
                <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold">Dados do recebedor</p>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Estabelecimento</span>
                  <span className="text-foreground font-medium">{storeName || 'Cremoso Burguer'}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Chave PIX</span>
                  <span className="text-foreground font-medium truncate max-w-[180px]">{pixKey}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Valor</span>
                  <span className="text-primary font-bold">{fmt(total)}</span>
                </div>
              </div>
            </>
          )}

          {/* Close button */}
          <Button
            variant="outline"
            onClick={onClose}
            className="w-full border-border text-muted-foreground hover:text-foreground"
          >
            {expired ? 'Fechar' : 'Já paguei — Fechar'}
          </Button>

        </div>
      </div>
    </div>
  )
}
