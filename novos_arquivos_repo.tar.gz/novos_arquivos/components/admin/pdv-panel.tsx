'use client'

import { useState, useEffect, useCallback } from 'react'
import { Plus, Minus, Search, ChefHat, CreditCard, Banknote, QrCode, Link as LinkIcon, Check, Trash2, TrendingDown, TrendingUp, RefreshCw, ShoppingBag, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useStore } from '@/lib/store'
import { deductStockForOrder } from '@/lib/estoque-utils'
import type { Product, PaymentMethod } from '@/lib/types'

/* ── Types ── */
interface PdvItem { product: Product; quantity: number; obs: string }
interface Bairro { id: string; nome: string; taxa_entrega: number }
interface CaixaMov { id: string; tipo: 'abertura' | 'fechamento' | 'sangria' | 'suprimento'; valor: number; obs: string; data: string }
interface CaixaData { isOpen: boolean; openedAt?: string; totalInicial: number; movimentos: CaixaMov[] }

const CAIXA_KEY = 'cremoso-caixa-v1'
const PAY_OPTIONS: { id: PaymentMethod; label: string; icon: React.ElementType }[] = [
  { id: 'pix', label: 'PIX', icon: QrCode },
  { id: 'cartao', label: 'Cartão', icon: CreditCard },
  { id: 'dinheiro', label: 'Dinheiro', icon: Banknote },
  { id: 'link', label: 'Link', icon: LinkIcon },
]

function loadCaixa(): CaixaData {
  try { return JSON.parse(localStorage.getItem(CAIXA_KEY) || 'null') || { isOpen: false, totalInicial: 0, movimentos: [] } }
  catch { return { isOpen: false, totalInicial: 0, movimentos: [] } }
}
function saveCaixa(d: CaixaData) {
  try { localStorage.setItem(CAIXA_KEY, JSON.stringify(d)) } catch { /* ignore */ }
}

const fmt = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const today = () => new Date().toISOString().slice(0, 10)
const fmtDate = (s: string) => new Date(s).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })

type Tab = 'pedido' | 'caixa' | 'historico'
type Step = 1 | 2 | 3

export function PdvPanel() {
  const { products, loadProducts } = useStore()
  const [tab, setTab] = useState<Tab>('pedido')

  /* ── Novo Pedido ── */
  const [step, setStep] = useState<Step>(1)
  const [cliente, setCliente] = useState({ name: '', phone: '', address: '', neighborhood: '' })
  const [bairros, setBairros] = useState<Bairro[]>([])
  const [items, setItems] = useState<PdvItem[]>([])
  const [search, setSearch] = useState('')
  const [payment, setPayment] = useState<PaymentMethod>('pix')
  const [discountRaw, setDiscountRaw] = useState('')
  const [discountType, setDiscountType] = useState<'fixo' | 'pct'>('fixo')
  const [coupon, setCoupon] = useState('')
  const [obs, setObs] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [lastOrder, setLastOrder] = useState<{ number: number; total: number } | null>(null)

  /* ── Caixa ── */
  const [caixa, setCaixa] = useState<CaixaData>({ isOpen: false, totalInicial: 0, movimentos: [] })
  const [caixaValor, setCaixaValor] = useState('')
  const [caixaObs, setCaixaObs] = useState('')
  const [caixaAction, setCaixaAction] = useState<'sangria' | 'suprimento' | null>(null)
  const [valorInicial, setValorInicial] = useState('')

  /* ── Histórico ── */
  const [orders, setOrders] = useState<{ number: number; customer: { name: string }; total: number; paymentMethod: string; status: string; createdAt: string }[]>([])
  const [loadingOrders, setLoadingOrders] = useState(false)

  useEffect(() => {
    loadProducts()
    setCaixa(loadCaixa())
    fetch('/api/admin/bairros').then(r => r.json()).then(j => setBairros(j.bairros || [])).catch(() => { })
  }, [loadProducts])

  const fetchOrders = useCallback(async () => {
    setLoadingOrders(true)
    try {
      const r = await fetch('/api/admin/orders')
      const j = await r.json()
      setOrders((j.orders || []).filter((o: { createdAt: string }) => o.createdAt?.slice(0, 10) === today()))
    } catch { /* ignore */ }
    finally { setLoadingOrders(false) }
  }, [])

  useEffect(() => { if (tab === 'historico') fetchOrders() }, [tab, fetchOrders])

  /* ── Pedido calcs ── */
  const deliveryFee = bairros.find(b => b.nome === cliente.neighborhood)?.taxa_entrega ?? 0
  const subtotal = items.reduce((s, i) => s + i.product.price * i.quantity, 0)
  const discountVal = (() => {
    const n = parseFloat(discountRaw) || 0
    return discountType === 'pct' ? Math.min(subtotal * n / 100, subtotal) : Math.min(n, subtotal)
  })()
  const total = subtotal + deliveryFee - discountVal

  const addItem = (p: Product) => {
    setItems(prev => {
      const idx = prev.findIndex(i => i.product.id === p.id)
      if (idx >= 0) { const n = [...prev]; n[idx].quantity++; return n }
      return [...prev, { product: p, quantity: 1, obs: '' }]
    })
  }
  const changeQty = (id: string, delta: number) => {
    setItems(prev => prev.map(i => i.product.id === id ? { ...i, quantity: Math.max(0, i.quantity + delta) } : i).filter(i => i.quantity > 0))
  }

  const resetPedido = () => {
    setStep(1); setCliente({ name: '', phone: '', address: '', neighborhood: '' })
    setItems([]); setSearch(''); setPayment('pix'); setDiscountRaw(''); setDiscountType('fixo'); setCoupon(''); setObs('')
    setLastOrder(null)
  }

  const handleSubmit = async () => {
    if (!cliente.name || !cliente.phone || items.length === 0) return
    setSubmitting(true)
    try {
      const r = await fetch('/api/admin/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer: cliente,
          items: items.map(i => ({ product: i.product, quantity: i.quantity, addons: [], observation: i.obs })),
          subtotal, deliveryFee, total, discount: discountVal,
          paymentMethod: payment, observation: obs, couponCode: coupon,
        }),
      })
      const j = await r.json()
      if (!r.ok) throw new Error(j.error)
      deductStockForOrder(items.map(i => ({ product: i.product, quantity: i.quantity, addons: [] })))
      setLastOrder({ number: j.order.number, total })
      setStep(1)
      setItems([]); setCoupon(''); setDiscountRaw(''); setObs('')
    } catch (e) { alert('Erro: ' + (e instanceof Error ? e.message : 'desconhecido')) }
    finally { setSubmitting(false) }
  }

  /* ── Caixa actions ── */
  const abrirCaixa = () => {
    const val = parseFloat(valorInicial) || 0
    const novo: CaixaData = {
      isOpen: true, openedAt: new Date().toISOString(), totalInicial: val,
      movimentos: [{ id: crypto.randomUUID(), tipo: 'abertura', valor: val, obs: 'Abertura de caixa', data: new Date().toISOString() }],
    }
    setCaixa(novo); saveCaixa(novo); setValorInicial('')
  }
  const fecharCaixa = () => {
    const saldo = caixa.movimentos.reduce((s, m) => m.tipo === 'sangria' ? s - m.valor : s + m.valor, 0)
    const novo: CaixaData = {
      ...caixa, isOpen: false,
      movimentos: [...caixa.movimentos, { id: crypto.randomUUID(), tipo: 'fechamento', valor: saldo, obs: `Fechamento. Saldo: ${fmt(saldo)}`, data: new Date().toISOString() }],
    }
    setCaixa(novo); saveCaixa(novo)
  }
  const addMovCaixa = () => {
    if (!caixaAction || !caixaValor) return
    const val = parseFloat(caixaValor) || 0
    if (val <= 0) return
    const novo: CaixaData = {
      ...caixa, movimentos: [...caixa.movimentos, { id: crypto.randomUUID(), tipo: caixaAction, valor: val, obs: caixaObs || caixaAction, data: new Date().toISOString() }],
    }
    setCaixa(novo); saveCaixa(novo); setCaixaValor(''); setCaixaObs(''); setCaixaAction(null)
  }
  const saldoCaixa = caixa.movimentos.reduce((s, m) => m.tipo === 'sangria' ? s - m.valor : s + m.valor, 0)
  const todayMoves = caixa.movimentos.filter(m => m.data?.slice(0, 10) === today())

  /* ── Histórico calcs ── */
  const histTotals = orders.reduce((acc, o) => {
    const m = o.paymentMethod as string
    acc[m] = (acc[m] || 0) + o.total
    acc.total = (acc.total || 0) + o.total
    return acc
  }, {} as Record<string, number>)

  const filteredProducts = products.filter(p => p.active !== false && (search === '' || p.name.toLowerCase().includes(search.toLowerCase())))

  /* ── Render ── */
  const tabCls = (t: Tab) => `px-4 py-2 text-sm font-semibold rounded-lg transition-colors ${tab === t ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-muted'}`

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">PDV Administrativo</h1>
        <p className="text-muted-foreground text-sm">Gestão interna de pedidos delivery</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 bg-muted/40 p-1 rounded-xl w-fit">
        <button className={tabCls('pedido')} onClick={() => { setTab('pedido'); setLastOrder(null) }}><ShoppingBag className="w-4 h-4 inline mr-1.5" />Novo Pedido</button>
        <button className={tabCls('caixa')} onClick={() => setTab('caixa')}><Banknote className="w-4 h-4 inline mr-1.5" />Caixa</button>
        <button className={tabCls('historico')} onClick={() => setTab('historico')}><ChefHat className="w-4 h-4 inline mr-1.5" />Histórico</button>
      </div>

      {/* ── NOVO PEDIDO ── */}
      {tab === 'pedido' && (
        <div className="space-y-4">
          {lastOrder && (
            <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-400" />
                <div>
                  <p className="font-bold text-foreground">Pedido #{String(lastOrder.number).padStart(3, '0')} criado!</p>
                  <p className="text-sm text-muted-foreground">Total: {fmt(lastOrder.total)}</p>
                </div>
              </div>
              <Button onClick={resetPedido} size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus className="w-4 h-4 mr-1" /> Novo
              </Button>
            </div>
          )}

          {/* Step indicator */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            {([1, 2, 3] as Step[]).map((s, i) => (
              <span key={s} className="flex items-center gap-2">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs ${step === s ? 'bg-primary text-primary-foreground' : step > s ? 'bg-green-500/20 text-green-400' : 'bg-muted text-muted-foreground'}`}>{step > s ? '✓' : s}</span>
                <span className={step === s ? 'text-foreground font-medium' : ''}>{['Cliente', 'Itens', 'Pagamento'][i]}</span>
                {i < 2 && <span className="text-muted-foreground/40">—</span>}
              </span>
            ))}
          </div>

          {/* Step 1: Cliente */}
          {step === 1 && (
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="font-bold text-foreground">Dados do Cliente</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5 col-span-2">
                  <Label className="text-foreground text-xs">Nome completo *</Label>
                  <Input value={cliente.name} onChange={e => setCliente({ ...cliente, name: e.target.value })} placeholder="João da Silva" className="bg-muted border-border text-foreground" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs">Telefone *</Label>
                  <Input value={cliente.phone} onChange={e => setCliente({ ...cliente, phone: e.target.value })} placeholder="(33) 99999-9999" className="bg-muted border-border text-foreground" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs">Endereço</Label>
                  <Input value={cliente.address} onChange={e => setCliente({ ...cliente, address: e.target.value })} placeholder="Rua das Flores, 123" className="bg-muted border-border text-foreground" />
                </div>
                <div className="space-y-1.5 col-span-2">
                  <Label className="text-foreground text-xs">Bairro</Label>
                  <select value={cliente.neighborhood} onChange={e => setCliente({ ...cliente, neighborhood: e.target.value })} className="w-full h-10 px-3 rounded-md bg-muted border border-border text-foreground text-sm">
                    <option value="">Selecione o bairro</option>
                    {bairros.map(b => <option key={b.id} value={b.nome}>{b.nome} — Taxa: {fmt(Number(b.taxa_entrega))}</option>)}
                  </select>
                </div>
              </div>
              <Button onClick={() => setStep(2)} disabled={!cliente.name || !cliente.phone} className="bg-primary hover:bg-primary/90 text-primary-foreground w-full">
                Próximo — Selecionar Itens
              </Button>
            </div>
          )}

          {/* Step 2: Itens */}
          {step === 2 && (
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-foreground">Selecionar Itens</h3>
                <span className="text-xs text-muted-foreground">{items.reduce((s, i) => s + i.quantity, 0)} item(s) — {fmt(subtotal)}</span>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar produto..." className="pl-9 bg-muted border-border text-foreground" />
              </div>
              <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto">
                {filteredProducts.map(p => {
                  const inCart = items.find(i => i.product.id === p.id)
                  return (
                    <div key={p.id} className={`border rounded-lg p-3 cursor-pointer transition-all ${inCart ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/40 bg-muted/30'}`} onClick={() => addItem(p)}>
                      <p className="text-xs font-semibold text-foreground leading-tight">{p.name}</p>
                      <p className="text-xs text-primary font-bold mt-0.5">{fmt(p.price)}</p>
                      {inCart && (
                        <div className="flex items-center gap-2 mt-2" onClick={e => e.stopPropagation()}>
                          <button onClick={() => changeQty(p.id, -1)} className="w-6 h-6 rounded-full bg-muted border border-border flex items-center justify-center text-foreground hover:bg-destructive/20"><Minus className="w-3 h-3" /></button>
                          <span className="text-xs font-bold text-foreground w-4 text-center">{inCart.quantity}</span>
                          <button onClick={() => changeQty(p.id, 1)} className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-primary-foreground"><Plus className="w-3 h-3" /></button>
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
              {items.length > 0 && (
                <div className="border-t border-border pt-3 space-y-1">
                  {items.map(i => (
                    <div key={i.product.id} className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">{i.quantity}× {i.product.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-foreground font-medium">{fmt(i.product.price * i.quantity)}</span>
                        <button onClick={() => changeQty(i.product.id, -999)} className="text-muted-foreground hover:text-destructive"><X className="w-3 h-3" /></button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep(1)} className="border-border text-muted-foreground flex-1">Voltar</Button>
                <Button onClick={() => setStep(3)} disabled={items.length === 0} className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1">
                  Próximo — Pagamento
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Pagamento */}
          {step === 3 && (
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="font-bold text-foreground">Pagamento e Revisão</h3>
              <div className="grid grid-cols-2 gap-2">
                {PAY_OPTIONS.map(m => (
                  <button key={m.id} type="button" onClick={() => setPayment(m.id)} className={`p-3 rounded-lg border flex items-center gap-2 transition-all text-sm ${payment === m.id ? 'border-primary bg-primary/10 text-primary' : 'border-border bg-muted text-muted-foreground hover:border-primary/40'}`}>
                    <m.icon className="w-4 h-4" />{m.label}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <div className="space-y-1.5 flex-1">
                  <Label className="text-foreground text-xs">Desconto</Label>
                  <Input type="number" min="0" value={discountRaw} onChange={e => setDiscountRaw(e.target.value)} placeholder="0" className="bg-muted border-border text-foreground" />
                </div>
                <div className="space-y-1.5 w-24">
                  <Label className="text-foreground text-xs">Tipo</Label>
                  <select value={discountType} onChange={e => setDiscountType(e.target.value as 'fixo' | 'pct')} className="w-full h-10 px-2 rounded-md bg-muted border border-border text-foreground text-sm">
                    <option value="fixo">R$</option>
                    <option value="pct">%</option>
                  </select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-foreground text-xs">Cupom (opcional)</Label>
                <Input value={coupon} onChange={e => setCoupon(e.target.value.toUpperCase())} placeholder="CODIGO" className="bg-muted border-border text-foreground uppercase" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-foreground text-xs">Observação (opcional)</Label>
                <textarea rows={2} value={obs} onChange={e => setObs(e.target.value)} className="w-full px-3 py-2 rounded-md bg-muted border border-border text-foreground text-sm resize-none placeholder:text-muted-foreground" placeholder="Sem cebola, etc." />
              </div>
              <div className="bg-muted/50 rounded-lg p-3 space-y-1 text-sm">
                {items.map(i => (
                  <div key={i.product.id} className="flex justify-between text-muted-foreground">
                    <span>{i.quantity}× {i.product.name}</span>
                    <span>{fmt(i.product.price * i.quantity)}</span>
                  </div>
                ))}
                <div className="border-t border-border pt-2 mt-1 space-y-1">
                  <div className="flex justify-between text-muted-foreground"><span>Entrega</span><span>{fmt(deliveryFee)}</span></div>
                  {discountVal > 0 && <div className="flex justify-between text-primary"><span>Desconto</span><span>-{fmt(discountVal)}</span></div>}
                  <div className="flex justify-between font-bold text-lg text-foreground"><span>TOTAL</span><span className="text-primary">{fmt(total)}</span></div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep(2)} className="border-border text-muted-foreground flex-1">Voltar</Button>
                <Button onClick={handleSubmit} disabled={submitting} className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1">
                  {submitting ? 'Salvando...' : 'Registrar Pedido'}
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── CAIXA ── */}
      {tab === 'caixa' && (
        <div className="space-y-4">
          <div className={`rounded-xl border p-5 ${caixa.isOpen ? 'bg-green-500/5 border-green-500/30' : 'bg-muted/40 border-border'}`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide">{caixa.isOpen ? 'Caixa aberto' : 'Caixa fechado'}</p>
                {caixa.isOpen && <p className="text-3xl font-bold text-primary mt-1">{fmt(saldoCaixa)}</p>}
                {caixa.isOpen && caixa.openedAt && <p className="text-xs text-muted-foreground mt-0.5">Aberto às {fmtDate(caixa.openedAt)}</p>}
              </div>
              {!caixa.isOpen ? (
                <div className="flex items-center gap-2">
                  <Input value={valorInicial} onChange={e => setValorInicial(e.target.value)} type="number" placeholder="Valor inicial" className="w-32 bg-muted border-border text-foreground text-sm" />
                  <Button onClick={abrirCaixa} className="bg-green-600 hover:bg-green-700 text-white">Abrir Caixa</Button>
                </div>
              ) : (
                <Button onClick={fecharCaixa} variant="outline" className="border-destructive/40 text-destructive hover:bg-destructive/10">Fechar Caixa</Button>
              )}
            </div>
          </div>

          {caixa.isOpen && (
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="font-bold text-foreground">Movimentação</h3>
              <div className="flex gap-2">
                <button onClick={() => setCaixaAction(caixaAction === 'sangria' ? null : 'sangria')} className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg border text-sm font-medium transition-all ${caixaAction === 'sangria' ? 'bg-destructive/10 border-destructive/40 text-destructive' : 'border-border text-muted-foreground hover:bg-muted'}`}>
                  <TrendingDown className="w-4 h-4" /> Sangria
                </button>
                <button onClick={() => setCaixaAction(caixaAction === 'suprimento' ? null : 'suprimento')} className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg border text-sm font-medium transition-all ${caixaAction === 'suprimento' ? 'bg-green-500/10 border-green-500/30 text-green-400' : 'border-border text-muted-foreground hover:bg-muted'}`}>
                  <TrendingUp className="w-4 h-4" /> Suprimento
                </button>
              </div>
              {caixaAction && (
                <div className="flex gap-2">
                  <Input value={caixaValor} onChange={e => setCaixaValor(e.target.value)} type="number" placeholder="Valor" className="bg-muted border-border text-foreground" />
                  <Input value={caixaObs} onChange={e => setCaixaObs(e.target.value)} placeholder="Observação" className="bg-muted border-border text-foreground flex-1" />
                  <Button onClick={addMovCaixa} className="bg-primary hover:bg-primary/90 text-primary-foreground shrink-0">Confirmar</Button>
                </div>
              )}
            </div>
          )}

          <div className="bg-card border border-border rounded-xl p-5 space-y-3">
            <h3 className="font-bold text-foreground text-sm">Movimentos de hoje</h3>
            {todayMoves.length === 0 ? (
              <p className="text-muted-foreground text-sm">Nenhuma movimentação hoje.</p>
            ) : (
              <div className="space-y-2">
                {todayMoves.map(m => (
                  <div key={m.id} className="flex items-center justify-between text-sm border-b border-border pb-2 last:border-0 last:pb-0">
                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${m.tipo === 'sangria' ? 'bg-destructive/10 text-destructive' : m.tipo === 'suprimento' ? 'bg-green-500/10 text-green-400' : 'bg-muted text-muted-foreground'}`}>{m.tipo}</span>
                      <span className="text-muted-foreground">{m.obs}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`font-bold ${m.tipo === 'sangria' ? 'text-destructive' : 'text-green-400'}`}>{m.tipo === 'sangria' ? '-' : '+'}{fmt(m.valor)}</span>
                      <span className="text-xs text-muted-foreground">{fmtDate(m.data)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── HISTÓRICO ── */}
      {tab === 'historico' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-foreground">Pedidos de hoje</h3>
            <Button onClick={fetchOrders} variant="outline" size="sm" className="border-border text-muted-foreground" disabled={loadingOrders}>
              <RefreshCw className={`w-3.5 h-3.5 mr-1 ${loadingOrders ? 'animate-spin' : ''}`} /> Atualizar
            </Button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'PIX', key: 'pix', color: 'text-yellow-400' },
              { label: 'Cartão', key: 'cartao', color: 'text-blue-400' },
              { label: 'Dinheiro', key: 'dinheiro', color: 'text-green-400' },
              { label: 'Total', key: 'total', color: 'text-primary' },
            ].map(({ label, key, color }) => (
              <div key={key} className="bg-card border border-border rounded-xl p-4">
                <p className="text-xs text-muted-foreground uppercase tracking-wide">{label}</p>
                <p className={`text-xl font-bold mt-1 ${color}`}>{fmt(histTotals[key] || 0)}</p>
              </div>
            ))}
          </div>
          {orders.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">Nenhum pedido hoje.</div>
          ) : (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr>{['Pedido', 'Cliente', 'Total', 'Pagamento', 'Status'].map(h => <th key={h} className="text-left px-4 py-3 text-xs text-muted-foreground font-semibold">{h}</th>)}</tr>
                </thead>
                <tbody>
                  {orders.map(o => (
                    <tr key={o.number} className="border-t border-border hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-3 font-bold text-foreground">#{String(o.number).padStart(3, '0')}</td>
                      <td className="px-4 py-3 text-muted-foreground">{o.customer?.name || '—'}</td>
                      <td className="px-4 py-3 text-primary font-bold">{fmt(o.total)}</td>
                      <td className="px-4 py-3"><span className="bg-muted px-2 py-0.5 rounded text-xs capitalize">{o.paymentMethod}</span></td>
                      <td className="px-4 py-3"><span className={`text-xs px-2 py-0.5 rounded-full font-medium ${o.status === 'entregue' ? 'bg-green-500/10 text-green-400' : o.status === 'novo' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>{o.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
