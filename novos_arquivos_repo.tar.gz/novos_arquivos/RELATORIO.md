# Relatório de Comparação — Cremoso Burguer
**Repositório comparado:** https://github.com/cremosoburguerr-collab/Cremosoburguer_.git
**Data:** 20/05/2026

---

## Resumo

| Item | Quantidade |
|------|-----------|
| Arquivos novos encontrados | 16 |
| Dependências novas necessárias | **Nenhuma** |
| Arquivos modificados | Não comparados (apenas novos) |

---

## Arquivos Novos (16 arquivos)

### 🔌 APIs — Backend

#### Sistema de Cupons de Desconto
| Arquivo | Função |
|---------|--------|
| `app/api/admin/cupons/route.ts` | CRUD de cupons (GET listar, POST criar) |
| `app/api/admin/cupons/[id]/route.ts` | Editar e deletar cupom por ID (PATCH, DELETE) |
| `app/api/cupom/validar/route.ts` | Valida cupom público no checkout (verifica validade, limite de uso, expiração) |
| `app/api/cupom/usar/route.ts` | Incrementa contador de uso ao finalizar pedido |

---

### 🖥️ Páginas Admin — Novas rotas do painel

| Arquivo | Rota acessível |
|---------|---------------|
| `app/equipe/admin/cupons/page.tsx` | `/equipe/admin/cupons` |
| `app/equipe/admin/crm/page.tsx` | `/equipe/admin/crm` |
| `app/equipe/admin/estoque/page.tsx` | `/equipe/admin/estoque` |
| `app/equipe/admin/pdv/page.tsx` | `/equipe/admin/pdv` |

---

### 🧩 Componentes — Painéis Admin

#### `components/admin/cupons-panel.tsx`
- Gerenciamento completo de cupons de desconto
- Tipos: percentual (%) ou valor fixo (R$)
- Controle de validade (data de expiração)
- Controle de limite de uso (ex: máximo 100 usos)
- Ativar/desativar cupons
- Visualização de uso atual

#### `components/admin/crm-panel.tsx`
- CRM completo de clientes construído a partir dos pedidos
- Segmentação automática: VIP, Recorrente, Em Risco, Inativo, Novo
- Métricas por cliente: total gasto, ticket médio, dias sem comprar, LTV
- Produtos favoritos por cliente
- Cupons utilizados por cliente
- Ações de remarketing via WhatsApp (reativação e fidelidade)
- Exportação de lista completa em CSV
- Requer campo `couponCode` e `discount` nos pedidos (ver nota de schema)

#### `components/admin/estoque-panel.tsx`
- Controle de insumos (ingredientes/materiais)
- Cadastro de fornecedores
- Movimentações: entrada, saída, perda, ajuste
- Receitas: vincula insumos a cada produto do cardápio
- Baixa automática de estoque ao confirmar pedido
- Alertas de estoque mínimo
- **Armazenamento:** localStorage (sem banco de dados)

#### `components/admin/pdv-panel.tsx`
- PDV (Ponto de Venda) para atendimento presencial
- Criação de pedidos direto pelo balcão (sem WhatsApp)
- Gestão de caixa: abertura, fechamento, sangria, suprimento
- Histórico de vendas do dia com totais por forma de pagamento
- Desconto manual por pedido (fixo ou percentual)
- Campo de cupom integrado
- Baixa automática de estoque ao finalizar

---

### 🧩 Componentes — Frontend Público

#### `components/pix-modal.tsx`
- Modal PIX alternativo com chave PIX fixa configurada nas settings
- QR Code gerado via API pública (`api.qrserver.com`) a partir da chave PIX
- Cronômetro regressivo de 30 minutos com alerta visual
- Código PIX copia-e-cola (padrão EMV)
- Botão "Gerar novo PIX" ao expirar
- **Diferença do atual:** usa chave PIX estática (não gera cobrança no MP)

#### `components/order-again.tsx`
- Componente "Pedir Novamente" para clientes que já fizeram pedidos
- Busca pedidos anteriores pelo número e telefone
- Mostra histórico de pedidos com opção de repetir
- Adiciona itens do pedido anterior ao carrinho automaticamente

---

### 📚 Utilitários — Lib

#### `lib/estoque-utils.ts`
- Tipos TypeScript: `Insumo`, `Movimentacao`, `Fornecedor`, `Receita`
- Funções de load/save em localStorage para cada entidade
- Função `deductStockForOrder()`: baixa automática ao confirmar pedido

#### `lib/whatsapp-messages.ts`
- Funções centralizadas para mensagens WhatsApp
- `getWhatsAppMessage(order, status)`: mensagens de status (preparando, pronto, entregue)
- `getPixMessage(order, pixKey)`: mensagem com chave PIX
- `openWhatsApp(phone, message)`: abre WhatsApp com normalização de telefone

---

## Funcionalidades Novas Identificadas

| Funcionalidade | Componente(s) | Banco Necessário |
|---------------|---------------|-----------------|
| Sistema de cupons de desconto | `cupons-panel`, `api/admin/cupons/*`, `api/cupom/*` | ✅ Tabela `cupons` no Supabase |
| CRM de clientes com segmentação | `crm-panel` | ❌ (usa pedidos existentes) |
| Controle de estoque e insumos | `estoque-panel`, `estoque-utils` | ❌ (localStorage) |
| PDV presencial com caixa | `pdv-panel` | ❌ (localStorage + pedidos existentes) |
| Modal PIX com chave estática | `pix-modal` | ❌ (chave das configurações) |
| "Pedir Novamente" | `order-again` | ❌ (usa API de pedidos existente) |
| Mensagens WhatsApp centralizadas | `whatsapp-messages` | ❌ |

---

## Dependências Novas Necessárias

> **Nenhuma.** Todos os arquivos novos usam apenas dependências já instaladas no projeto atual
> (`date-fns`, `lucide-react`, `@supabase/supabase-js`, Tailwind, shadcn/ui).

---

## Schema de Banco — Alterações Necessárias (se quiser importar)

### Para o sistema de Cupons:
```sql
create table if not exists cupons (
  id uuid primary key default gen_random_uuid(),
  codigo text unique not null,
  desconto_tipo text not null check (desconto_tipo in ('percentual', 'fixo')),
  desconto_valor numeric(10,2) not null default 0,
  validade date,
  limite_uso int,
  uso_atual int not null default 0,
  ativo boolean not null default true,
  created_at timestamptz default now()
);

alter table cupons enable row level security;

drop policy if exists "Public read cupons" on cupons;
create policy "Public read cupons" on cupons for select using (true);
```

### Para o CRM (campos opcionais nos pedidos):
```sql
-- Adicionar se quiser rastrear desconto e cupom por pedido:
alter table pedidos add column if not exists discount numeric(10,2) default 0;
alter table pedidos add column if not exists coupon_code text;
```

---

## Observações

- **Projeto atual preservado:** nenhum arquivo foi alterado
- **Todos os 16 arquivos** estão incluídos neste zip prontos para uso
- **Estoque e PDV** funcionam offline (localStorage) — sem migração de banco necessária
- **Cupons** requerem criação da tabela `cupons` no Supabase antes de ativar
- **CRM** já funciona com os pedidos existentes, sem alteração de schema
