'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useStore } from '@/lib/store'
import { AdminSidebar } from '@/components/admin/sidebar'
import { CRMPanel } from '@/components/admin/crm-panel'

export default function CRMPage() {
  const router = useRouter()
  const { user } = useStore()

  useEffect(() => {
    if (!user) router.push('/equipe')
  }, [user, router])

  if (!user) return null

  return (
    <div className="min-h-screen bg-background">
      <AdminSidebar />
      <main className="ml-64">
        <CRMPanel />
      </main>
    </div>
  )
}
